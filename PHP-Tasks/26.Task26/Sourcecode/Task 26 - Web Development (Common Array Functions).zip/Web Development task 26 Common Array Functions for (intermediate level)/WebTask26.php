
<!DOCTYPE html>
<html>
<head>
	<title>Array Functions</title>
</head>
<body>
<h2>Array Functions</h2>
<?php 
	$array = [1,2,3,4,5,6];

	//Removes first element from an array
	array_shift($array);

	//Write php array function to prepend an element at the top of array

	//Write php array function to add an element at the end of an array

	//Write php array function to remove last element from an array



?>

</body>
</html>
