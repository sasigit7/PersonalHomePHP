<html>
  <head>
    <title>Photo Gallery: Admin</title>
    <link href="../stylesheets/main.css" media="all" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <div id="header">
      <h1>Photo Gallery: Admin</h1>
    </div>
    <div id="main">
