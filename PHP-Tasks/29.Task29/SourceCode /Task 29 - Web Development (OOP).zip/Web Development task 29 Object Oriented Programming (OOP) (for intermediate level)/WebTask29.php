<?php 

class Person {
	// Add a constructor to this class that should recieve a paramter $message and assign it to $message property of class
	public $message;
	function say_hello() {
		echo $this->message();
	}
}

// Create Two objects of class Person. 

?>