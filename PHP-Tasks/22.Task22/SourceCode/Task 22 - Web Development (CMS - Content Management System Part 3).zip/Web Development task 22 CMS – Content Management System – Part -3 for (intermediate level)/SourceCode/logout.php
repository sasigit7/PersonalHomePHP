<?php 
// remove flag from $_SESSION and use header('Location: ') to redirect user to login.php page


?>